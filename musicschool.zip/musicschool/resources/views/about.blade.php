@extends('layout')

@section('content')
    <h1> The About page Goes Here </h1>
@stop

@section('footer')
	<script type="text/javascript">
		alert('About Page');
	</script>
@stop