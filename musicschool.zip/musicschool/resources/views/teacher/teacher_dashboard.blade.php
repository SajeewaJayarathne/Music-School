@extends('teacher.teacher_dashboard_template')

@section('content_area_main')

<div style="color: white; text-align:center; padding:10px 10px;">
  <h3>TEACHER DASHBOARD</h3>                                             
</div>

@stop