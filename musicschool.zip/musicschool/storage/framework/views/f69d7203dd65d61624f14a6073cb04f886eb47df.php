<?php $__env->startSection('content_area_main'); ?>

    <div style="color: white; text-align:center; padding:10px 10px;">
        <h3>STUDENT ATTENDANCE</h3>
    </div>

    <form>
        <div class="list-in-a-row" style="margin-left: 2%;">
            <ul>
                <li><h4 style="padding-right:5px;">Lesson :</h4></li>
                <li><h4 style="padding-right:5px;"><?php echo e($studentList[0]); ?> </h4></li>
            </ul>

            <ul>
                <li><h4 style="padding-right:5px;">Date :</h4></li>
                <li><h4 style="padding-right:5px;"><?php echo e($studentList[1]); ?> </h4></li>
            </ul>
        </div>

        <div class="col-md-10" style="margin-left: 10%; margin-bottom: 2%; font-size: 20px;">
            <table>
                <?php $__currentLoopData = $studentList[2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($row -> student_id); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </table>
        </div>

    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('teacher.teacher_dashboard_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>