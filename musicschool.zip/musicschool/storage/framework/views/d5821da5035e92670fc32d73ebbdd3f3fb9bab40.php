<?php $__env->startSection('content_area_main'); ?>

    <div style="color: white; text-align:center; padding:10px 10px;">
        <h3>VIEW MY PAYMENTS</h3>
    </div>

    <form>
        <div class="col-md-10" style="margin-left: 2.2%; margin-bottom: 2%; margin-top: 2%; font-size: large;">
            <table border="0" cellspacing="20" cellpadding="30">
                <tr>
                    <th style="padding: 0 30px;">Receipt ID</th>
                    <th style="padding: 0 30px;">Amount</th>
                    <th style="padding: 0 30px;">Last Updated</th>

                </tr>
                <?php $__currentLoopData = $teacherPayments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td style="padding: 0 30px;"><?php echo e($row -> receipt_id); ?></td>
                        <td style="padding: 0 30px;"><?php echo e($row -> amount); ?>  LKR</td>
                        <td style="padding: 0 30px;"><?php echo e($row -> last_updated); ?></td>

                   </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </table>
        </div>


    </form>

    

<?php $__env->stopSection(); ?>


<?php echo $__env->make('teacher.teacher_dashboard_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>