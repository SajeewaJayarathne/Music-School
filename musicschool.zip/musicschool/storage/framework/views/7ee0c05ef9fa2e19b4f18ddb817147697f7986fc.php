<?php $__env->startSection('main_menu'); ?>
	<li data-toggle="collapse" data-target="#add_users" ><a href="#"><span>Add Users</span></a>
		<ul id="add_users" class="collapse" >
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_students")); ?>'">Student</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_teachers")); ?>'">Teacher</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_admin")); ?>'">Administrator</a></li>
		</ul>
	</li>

	<li data-toggle="collapse" data-target="#classes" ><a href="#"><span>Classes</span></a>
		<ul id="classes" class="collapse">
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_classroom")); ?>'" >Add Classrooms</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("getClassroomList")); ?>'">View Classrooms</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("allocateClassrooms")); ?>'">Allocate Classrooms</a></li>
			<li><a href="#">Update Allocations</a></li>
		</ul>
	</li>

	<li data-toggle="collapse" data-target="#instruments"><a href="#"><span>Instruments</span></a>
		<ul id="instruments" class="collapse">
			<li><a href="#" onclick="window.location ='<?php echo e(route("getInstrumentList")); ?>'">View Instruments</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_instruments")); ?>'">Add Instruments</a></li>
		</ul>
	</li>

	<li data-toggle="collapse" data-target="#payments"><a href="#"><span>Payments</span></a>
		<ul id="payments" class="collapse">
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_student_payments")); ?>'">Add Student Payments</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("update_student_payments")); ?>'">Update Student Payments</a></li>
			<li><a href="#">View Teachers Payments</a></li>
			<li><a href="#">Update Teachers Payments</a></li>
		</ul>
	</li>

	<li data-toggle="collapse" data-target="#attendance"><a href="#"><span>Attendance</span></a>
		<ul id="attendance" class="collapse">
			<li><a href="#">View Teachers Attendance</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("add_teacher_attendance")); ?>'">Add Teachers Attendance</a></li>
			<li><a href="#" onclick="window.location ='<?php echo e(route("view_student_attendance")); ?>'">View Student Attendance</a></li>
		</ul>
	</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content_area'); ?>
	<?php echo $__env->yieldContent('content_area_main'); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('MainLayout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>