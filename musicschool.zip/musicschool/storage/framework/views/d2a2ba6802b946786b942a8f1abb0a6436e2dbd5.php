<?php $__env->startSection('content_area_main'); ?>
    <div style="color: white; text-align:center; padding:10px 10px;">
        <h3>CLASSROOMS</h3>
    </div>

    <div class="col-md-10" style="margin-left: 2.2%; margin-bottom: 2%; margin-top: 2%; font-size: large;">
        <table border="0" cellspacing="20" cellpadding="30">
            <tr>
                <th style="padding: 0 30px;">Room Number</th>
                <th style="padding: 0 30px;">Building</th>
                <th style="padding: 0 30px;">Room Capacity</th>
                <th style="padding: 0 30px;">Room Type</th>
            </tr>
            <?php $__currentLoopData = $classRoomList[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td style="padding: 0 30px;"><?php echo e($row -> room_number); ?></td>
                    <td style="padding: 0 30px;"><?php echo e($row -> building); ?></td>
                    <td style="padding: 0 30px;"><?php echo e($row -> capacity); ?></td>
                    <td style="padding: 0 30px;"><?php echo e($row -> room_type); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>