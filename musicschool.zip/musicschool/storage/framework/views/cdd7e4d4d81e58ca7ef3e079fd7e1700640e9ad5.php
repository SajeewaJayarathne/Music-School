<?php $__env->startSection('content_area_main'); ?>

    <div style="color: white; text-align:center; padding:10px 10px;">
        <h3>STUDENT DASHBOARD</h3>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.student_dashboard_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>