<?php $__env->startSection('main_content'); ?>
	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>

    	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>

    	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>

    	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>

    	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>

    	<div class="row">
		<div class = "col-md-9" style="margin-left: 3%; color: white">
			<h3> Mark attendance</h3>
			<div class="row" style="position:">
				<h4>Index No</h4>
				<input class="form-control" type = "text" name="index_no" id="index_no">
				<button type="mark_attendance" class="btn btn-primary1">Login</button>
			</div>
		</div>
   		 
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('MainLayout.mainlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>