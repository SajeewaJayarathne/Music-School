<?php $__env->startSection('content_area_main'); ?>
    <div style="color: white; text-align:center; padding:10px 10px;">
        <h3>INSTRUMENTS</h3>
    </div>

    <div class="col-md-10" style="margin-left: 2.2%; margin-bottom: 2%; margin-top: 2%; font-size: large;">
        <table border="0" cellspacing="20" cellpadding="30">
            <tr>
                <th style="padding: 0 30px;">Instrument Id</th>
                <th style="padding: 0 30px;">Instrument Name</th>
                <th style="padding: 0 30px;">Category</th>

            </tr>
            <?php $__currentLoopData = $instrumentList[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td style="padding: 0 30px;"><?php echo e($row -> instrument_id); ?></td>
                    <td style="padding: 0 30px;"><?php echo e($row -> instrument_name); ?></td>
                    <td style="padding: 0 30px;"><?php echo e($row -> category); ?></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>